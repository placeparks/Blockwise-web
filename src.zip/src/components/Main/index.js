import Hero from './Hero';

export default function Home(){
return(
<>
<Hero/>
</>
)
}